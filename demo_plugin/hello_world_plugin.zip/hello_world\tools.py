def say_hello(name: str) -> str:
    """
    Returns a greeting message.
    """
    return f"Hello, {name}! Welcome to K8s AIOps Agent Plugin System."
